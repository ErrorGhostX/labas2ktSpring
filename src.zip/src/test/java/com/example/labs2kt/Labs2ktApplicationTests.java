package com.example.labs2kt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labs2ktApplicationTests {

    @Test
    void contextLoads() {
    }

}
