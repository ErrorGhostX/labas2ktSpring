-- Очистка таблиц перед вставкой данных
DELETE FROM Agreement;
DELETE FROM Account;
DELETE FROM TypeAccount;
DELETE FROM Bank;

-- Вставка данных о банках
INSERT INTO Bank (name) VALUES ('Тинькофф Банк');
INSERT INTO Bank (name) VALUES ('Сбербанк');
INSERT INTO Bank (name) VALUES ('Альфа-Банк');

-- Вставка типов счетов
INSERT INTO TypeAccount (type_name) VALUES ('Сберегательный');
INSERT INTO TypeAccount (type_name) VALUES ('Текущий');
INSERT INTO TypeAccount (type_name) VALUES ('Корпоративный');

-- Вставка счетов клиентов
INSERT INTO Account (client_name, balance, bank_id, type_account_id, created_at)
VALUES ('Иван Иванов', 15000.00, 1, 1, NOW());
INSERT INTO Account (client_name, balance, bank_id, type_account_id, created_at)
VALUES ('Петр Петров', 25000.50, 2, 2, NOW());
INSERT INTO Account (client_name, balance, bank_id, type_account_id, created_at)
VALUES ('Мария Сидорова', 35000.75, 3, 3, NOW());

-- Вставка соглашений
INSERT INTO Agreement (agreement_number, account_id, created_at)
VALUES ('AG-001', 1, NOW());
INSERT INTO Agreement (agreement_number, account_id, created_at)
VALUES ('AG-002', 2, NOW());
INSERT INTO Agreement (agreement_number, account_id, created_at)
VALUES ('AG-003', 3, NOW());
