-- Создание таблицы банков
CREATE TABLE IF NOT EXISTS Bank (
                                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                    name VARCHAR(100) NOT NULL
    );

-- Создание таблицы типов счетов
CREATE TABLE IF NOT EXISTS TypeAccount (
                                           id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                           type_name VARCHAR(50) NOT NULL
    );

-- Создание таблицы счетов клиентов
CREATE TABLE IF NOT EXISTS Account (
                                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                       client_name VARCHAR(100) NOT NULL,
    balance DECIMAL(15, 2) NOT NULL,
    bank_id BIGINT NOT NULL,
    type_account_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (bank_id) REFERENCES Bank(id),
    FOREIGN KEY (type_account_id) REFERENCES TypeAccount(id)
    );

-- Создание таблицы соглашений
CREATE TABLE IF NOT EXISTS Agreement (
                                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                         agreement_number VARCHAR(50) NOT NULL,
    account_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (account_id) REFERENCES Account(id)
    );
