package com.example.labs2kt.model;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "agreements")
public class Agreement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Идентификатор соглашения

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account; // Счет, к которому относится соглашение

    @Column(nullable = false)
    private String agreementDetails; // Детали соглашения

    @Column(name = "signed_at", nullable = false)
    private Date signedAt; // Дата подписания соглашения

    public Agreement() {
        // Конструктор по умолчанию
    }

    public Agreement(Account account, String agreementDetails, Date signedAt) {
        this.account = account;
        this.agreementDetails = agreementDetails;
        this.signedAt = signedAt;
    }

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public String getAgreementDetails() {
        return agreementDetails;
    }

    public void setAgreementDetails(String agreementDetails) {
        this.agreementDetails = agreementDetails;
    }

    public Date getSignedAt() {
        return signedAt;
    }

    public void setSignedAt(Date signedAt) {
        this.signedAt = signedAt;
    }
}