package com.example.labs2kt.model;
import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "accounts")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Идентификатор счета

    @Column(nullable = false)
    private double balance; // Баланс счета

    @ManyToOne
    @JoinColumn(name = "bank_id", nullable = false)
    private Bank bank; // Связь с банком

    @ManyToOne
    @JoinColumn(name = "type_account_id", nullable = false)
    private TypeAccount typeAccount; // Тип счета

    @Column(name = "created_at", nullable = false)
    private Date createdAt; // Дата создания счета

    public Account() {
        // Конструктор по умолчанию
    }

    public Account(double balance, Bank bank, TypeAccount typeAccount, Date createdAt) {
        this.balance = balance;
        this.bank = bank;
        this.typeAccount = typeAccount;
        this.createdAt = createdAt;
    }

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public TypeAccount getTypeAccount() {
        return typeAccount;
    }

    public void setTypeAccount(TypeAccount typeAccount) {
        this.typeAccount = typeAccount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
