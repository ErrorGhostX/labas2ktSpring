package com.example.labs2kt.model;

import jakarta.persistence.*;

@Entity
@Table(name = "type_accounts")
public class TypeAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Идентификатор типа счета

    @Column(nullable = false)
    private String name; // Название типа счета

    @Column(nullable = false)
    private String description; // Описание типа счета

    public TypeAccount() {
        // Конструктор по умолчанию
    }

    public TypeAccount(String name, String description) {
        this.name = name;
        this.description = description;
    }

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}