package com.example.labs2kt.model;

import jakarta.persistence.*;
@Entity
@Table(name = "banks")
public class Bank {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Идентификатор банка

    @Column(nullable = false)
    private String name; // Название банка

    @Column(nullable = false)
    private String location; // Местоположение банка

    public Bank() {
        // Конструктор по умолчанию
    }

    public Bank(String name, String location) {
        this.name = name;
        this.location = location;
    }

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
