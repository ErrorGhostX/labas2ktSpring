package com.example.labs2kt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labs2ktApplication {

    public static void main(String[] args) {
        SpringApplication.run(Labs2ktApplication.class, args);
    }

}
